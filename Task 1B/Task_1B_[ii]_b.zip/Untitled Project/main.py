import pandas as pd
import matplotlib.pyplot as plt

# Create a sample DataFrame
data = {
    'A': [10, 20, 30, 40],
    'B': [15, 25, 35, 45],
    'C': [20, 30, 40, 50]
}
df = pd.DataFrame(data, index=['X', 'Y', 'Z', 'W'])

# Plotting
df.plot(kind='bar', figsize=(10, 6))
plt.title('Bar Plot with DataFrame')
plt.xlabel('Index')
plt.ylabel('Values')
plt.xticks(rotation=0)
plt.legend(title='Columns')
plt.grid(axis='y')
plt.show()

# Plotting stacked bar plot
df.plot(kind='bar', stacked=True, figsize=(10, 6))
plt.title('Stacked Bar Plot with DataFrame')
plt.xlabel('Index')
plt.ylabel('Values')
plt.xticks(rotation=0)
plt.legend(title='Columns', loc='upper left')
plt.grid(axis='y')
plt.show()
