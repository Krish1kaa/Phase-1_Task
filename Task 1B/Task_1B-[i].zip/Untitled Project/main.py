import matplotlib.pyplot as plt
import numpy as np

# Create some data
x = np.linspace(0, 10, 100)
y1 = np.sin(x)
y2 = np.cos(x)

# Create subplots
fig, axs = plt.subplots(2, 1, figsize=(10, 8))

# Plot data on the first subplot
axs[0].plot(x, y1, label='sin(x)', color='blue', linestyle='--')
axs[0].set_title('Trigonometric Functions')
axs[0].set_xlabel('x')
axs[0].set_ylabel('y')
axs[0].legend()
axs[0].grid(True)
axs[0].annotate('Maximum', xy=(np.pi/2, 1), xytext=(3, 1.5),
                arrowprops=dict(facecolor='black', shrink=0.05))

# Plot data on the second subplot
axs[1].plot(x, y2, label='cos(x)', color='red', linestyle='-.')
axs[1].set_xlabel('x')
axs[1].set_ylabel('y')
axs[1].legend()
axs[1].grid(True)
axs[1].annotate('Minimum', xy=(3*np.pi/2, -1), xytext=(6, -1.5),
                arrowprops=dict(facecolor='black', shrink=0.05))

# Set common ticks and tick labels
for ax in axs.flat:
    ax.set_xticks([0, np.pi, 2*np.pi, 3*np.pi])
    ax.set_xticklabels(['0', '$\pi$', '$2\pi$', '$3\pi$'])

# Adjust layout
plt.tight_layout()

# Save the plot
plt.savefig('trigonometric_functions.png')

# Show the plot
plt.show()
