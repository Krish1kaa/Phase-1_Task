import pandas as pd
import numpy as np
data = {
    'A': [1, 2, np.nan, 4, 5],
    'B': ['a', 'b', 'c', 'd', 'e'],
    'C': [1, 2, 3, 4, 5]
}
df = pd.DataFrame(data)
missing_data = df.isna()
print("Missing Data:")
print(missing_data)
cleaned_df = df.dropna()
print("\nFiltered Data (After dropping rows with missing data):")
print(cleaned_df)
# Exclude non-numeric values
numeric_df = df.apply(pd.to_numeric, errors='coerce')

# Fill missing values with the mean
filled_df = numeric_df.fillna(numeric_df.mean())
print("\nFilled Data (After filling missing data with mean):")
print(filled_df)
duplicate_rows = df.duplicated()
print("\nDuplicate Rows:")
print(duplicate_rows)

deduplicated_df = df.drop_duplicates()
print("\nDeduplicated Data:")
print(deduplicated_df)
