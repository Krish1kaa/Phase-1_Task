import pandas as pd

# Create a Series with hierarchical indexing
data = [1, 2, 3, 4, 5, 6]
index = [['A', 'A', 'A', 'B', 'B', 'B'], [1, 2, 3, 1, 2, 3]]
series = pd.Series(data, index=index)

# Display the Series
print("Series with hierarchical indexing:")
print(series)

# Select subsets of data at outer and inner levels using partial indexing
print("\nSelecting subsets of data:")
print("Outer level 'A':")
print(series['A'])
print("\nInner level 2:")
print(series[:, 2])
